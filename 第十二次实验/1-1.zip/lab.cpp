#include <iostream>

#include "client.h"
using namespace std;

int main(int argc, char const *argv[]) {
    int len;
    cin >> len;
    char n;
    for (int i = 0; i < len; i++) {
        cin >> n;
        cout << n << endl << i + 1 << endl;
    }

    return 0;
}
